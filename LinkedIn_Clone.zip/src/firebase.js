import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';


const firebaseConfig = {
  apiKey: "AIzaSyAhYq35WZpgpQvRLXNJVnvnWWoiqORxBMM",
  authDomain: "linkedin-clone-aa7b8.firebaseapp.com",
  projectId: "linkedin-clone-aa7b8",
  storageBucket: "linkedin-clone-aa7b8.appspot.com",
  messagingSenderId: "617359935966",
  appId: "1:617359935966:web:03856651323c167563354f"
};

  //for connection to server
  const firebaseApp = firebase.initializeApp(firebaseConfig);

  //for creating firebasestore database
  // const db = firebaseApp.firestore();
  const db = firebaseApp.firestore();

  const auth = firebase.auth();

  export {db};

import React, { useState } from 'react';
import Avatar from '@mui/material/Avatar';
import InsertPhotoIcon from '@mui/icons-material/InsertPhoto';
import YouTubeIcon from '@mui/icons-material/YouTube';
import TodayIcon from '@mui/icons-material/Today';
import AssignmentIcon from '@mui/icons-material/Assignment';
import Post from "./Post"
import './Feed.css'
import {db} from "./firebase.js";
import { useEffect } from 'react';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';
// import { set } from 'immer/dist/internal';
// import { doc, setDoc, Timestamp } from "firebase/firestore"; 


function Feed() {
    const[posts, setPost] = useState();
    const [input, setInput] = useState();

    const submitPost = async (e) => {
        //in default state site gets refreshed everytime when enter is clicked
        //so to prevent this
        e.preventDefault();

        db.collection("posts").add({
            name:"shravani p",
            description: "problem solver",
            message : input,
            photoURl: "https://www.google.com",
            timestamp : firebase.firestore.FieldValue.serverTimestamp()
        });

        //set input field to blank
        setInput("");
    }

    useEffect(() => {
        db.collection("posts").orderBy("timestamp", "desc").onSnapshot(snapshot => {
            setPost(snapshot.docs.map(doc =>({
                id:doc.id,
                data: doc.data()
            })))
        });
    }, [])

  return (
    <div className='feed'>
        <div className='feed2'>
        <div className='feed_input'>
            <Avatar/>
            <form onSubmit={submitPost}>
                <input type="text" placeholder="Start a Post" value={input} onChange={e=>setInput(e.target.value)}/>
                <input type="submit"/>
            </form>
        </div>

        <div className='feed_options'>
            <div className='options'>
                <InsertPhotoIcon style={{color:'#00BFFF'}}/> 
                <span>Photo</span>
            </div>
            <div className='options'>
                <YouTubeIcon style={{color:'#ff0000'}}/> 
                <span>Video</span>
            </div>
            <div className='options'>
                <TodayIcon style={{color:'#FFA500'}}/> 
                <span>Event</span>
            </div>
            <div className='options'>
                <AssignmentIcon style={{color:'#FFC0CB'}}/> 
                <span>Write Artical</span>
            </div>
        </div>
        </div>

{
    posts.map(({id, data : {name, description, message, photoURL}}) => {
        return <Post key={id} name={name} description={description} message={message} photoURL={photoURL}/>
    })
}

    </div>
  )
}

export default Feed

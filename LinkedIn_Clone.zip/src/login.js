import { EmailOutlined } from '@mui/icons-material';
import React from 'react'
import {useState} from 'react'
import './login.css'

function Login() {
    const [signup, setsignup] = useState(false);
    const [name, setname] = useState("");
    const [photoURL, setphotoURL] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");

    const register = (e) => {
        e.preventDefault();

        if(!name){
            return alert("name is required.")
        }
        if(!email){
            return alert("email is required.")
        }
        if(!photoURL){
            return alert("photoURL is required.")
        }
        if(!password){
            return alert("password is required.")
        }
        setname("")
        setemail("")
        setphotoURL("")
        setpassword("")
    }

    return (
        <>
            <div className='loginscreen'>
                <img src='https://www.edigitalagency.com.au/wp-content/uploads/Linkedin-logo-png.png' />
                {
                    signup === true ?
                        (
                            <form onSubmit={register}>
                                <input type="text" placeholder='Full Name' value={name} onChange={e=>setname(e.target.value)}/>
                                <input type="text" placeholder='Profile picture URL' value={photoURL} onChange={e=>setphotoURL(e.target.value)}/>
                                <input type="email" placeholder='Email' value={email} onChange={e=>setemail(e.target.value)}/>
                                <input type="password" placeholder='Password' value={password} onChange={e=>setpassword(e.target.value)}/>
                                <input type="submit" value="sign up" />
                                <h4>Already signed up? <span onClick={e => setsignup(false)}>login here</span></h4>
                            </form>
                        ) : (
                            <form>
                                <input type="email" placeholder='Email' />
                                <input type="password" placeholder='Password' />
                                <input type="submit" value="sign in" />
                                <h4>Not a member? <span onClick={e => setsignup(true)}>Register here</span></h4>
                            </form>
                        )
                }
            </div>
        </>
    );
}
export default Login;


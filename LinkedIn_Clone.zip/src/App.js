import React from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import Feed from "./Feed";
import Rightsidebar from "./Rightsidebar";
import Login from "./login";

function App() {
  const user = "abc";

  return (
    <>
    {
      !user ?(<Login/>):(
        <div className="app_wrapper">
        <Header/>
        <div className="app_body">
            <Sidebar/>
            <Feed/>
            <Rightsidebar/>
        </div>
    </div>
  )
    }
    </>
  );
}

export default App;

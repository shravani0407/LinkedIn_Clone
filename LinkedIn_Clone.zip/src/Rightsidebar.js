import React from 'react'
import InfoIcon from '@mui/icons-material/Info';
import "./Rightsidebar.css"

function Rightsidebar() {
  return (
    <div className='Rightsidebar'>
        <div className='widget_top'>
            <div className='widget_header'>
                <h4>Linkedin News</h4>
                <InfoIcon/>
            </div>

            <div className='widget_body'>
                <ul className='rightside_options'>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                </ul>
            </div>
        </div>

        <div className='widget_bottom'>
            <div className='widget_header'>
                <h4>Linkedin News</h4>
                <InfoIcon/>
            </div>

            <div className='widget_body'>
                <ul className='rightside_options'>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                    <li>
                        <h4>gj,gkj,</h4>
                        <p>utukytgjmhgjhg</p>
                    </li>
                </ul>
            </div>

        </div>
      
    </div>
  )
}

export default Rightsidebar

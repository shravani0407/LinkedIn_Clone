import React from 'react'
import Avatar from '@mui/material/Avatar'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import "./Post.css"
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import CommentIcon from '@mui/icons-material/Comment';
import ShareIcon from '@mui/icons-material/Share';
import SendIcon from '@mui/icons-material/Send';

function Post({name, description, message, photoURL}) {
  return (
    <div className='post'>
      <div className='post_header'>

          <div className='post_headerleft'>
            <Avatar src={photoURL}/>
            <div className='post_profiledetails'>
                <h3>{name}</h3>
                <p>{description}</p>
            </div>
          </div>
          
          <MoreVertIcon/>
      </div>
      <div className='post_body'>
          <p>{message}</p>
      </div>
      <div className='post_footer'>
          <div className='post_options'>
          <ThumbUpIcon/>
          <span> like</span>
          </div>
          <div className='post_options'>
          <CommentIcon/>
          <span> Comment</span>
          </div>
          <div className='post_options'>
          <ShareIcon/>
          <span> Share</span>
          </div>
          <div className='post_options'>
          <SendIcon/>
          <span> Send</span>
          </div>
      </div>
    </div>
  )
}

export default Post
